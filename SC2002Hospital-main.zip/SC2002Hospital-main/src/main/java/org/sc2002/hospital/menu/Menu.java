package org.sc2002.hospital.menu;
import java.util.ArrayList;
import java.util.Scanner;
public interface Menu {
    void run();
}
